package steps;

import java.time.Duration;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Hooks extends BaseClass {
//	@Before
//	public void precondition() {
//		WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//		driver.get("http://leaftaps.com/opentaps");
//		sAssert = new SoftAssert();
//	}
//
//	@After
//	public void postcondition() throws InterruptedException {
//		Thread.sleep(5000);
//		driver.close();
//		sAssert.assertAll();
//	}
}