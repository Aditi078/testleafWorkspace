package steps;

import org.openqa.selenium.By;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class DeleteLead extends BaseClass {

	@Given("Click on the Phone")
	public void clickPhone() {
		driver.findElement(By.linkText("Phone")).click();
	}

	@Given("Enter the phone number {string}")
	public void clickPhoneNumber(String phn) {
		driver.findElement(By.name("phoneCountryCode")).clear();
		driver.findElement(By.name("phoneNumber")).sendKeys(phn);
	}

	@Given("Enter captured lead ID")
	public void capLeadID() {
		driver.findElement(By.name("id")).sendKeys(EditLead.leadIDText);
	}

	@Then("Verify message No records to display in the Lead List")
	public void varifyDisplay() {
		boolean noRecordsDisplay = driver.findElement(By.className("x-paging-info")).isDisplayed();
		sAssert.assertTrue(noRecordsDisplay);
	}
}
