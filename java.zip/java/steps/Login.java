package steps;

import org.openqa.selenium.By;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class Login extends BaseClass {

	@Given("Enter Username as {string}")
	public void enterUserName(String userName) {
		driver.findElement(By.id("username")).sendKeys(userName);
	}

	@And("Enter password as {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}

	@When("Click on Login button")
	public void clickonloginbutton() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@When("Click on {string} link")
	public void clickLink(String link) {
		driver.findElement(By.linkText(link)).click();
	}
}