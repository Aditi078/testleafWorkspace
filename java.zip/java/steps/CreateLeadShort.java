package steps;

import org.openqa.selenium.By;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class CreateLeadShort extends BaseClass {

	@Given("Enter company name {string}")
	public void enterCompanyNameTier5(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
	}

	@Given("Enter first name {string}")
	public void firstName(String fName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
	}

	@Given("Enter last name {string}")
	public void lastName(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
	}

	@Given("Click Submit button")
	public void clickSubmit() {
		driver.findElement(By.name("submitButton")).click();
	}

	@Then("First Name should be {string}")
	public void varifyFirstName(String firstName) {
		String name = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		sAssert.assertEquals(name, firstName);
	}

	@Then("{string} Page should be displayed")
	public void verifyPage(String page) {
		String actualTitle = driver.getTitle();
		sAssert.assertTrue(actualTitle.contains(page));

	}

}