package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class EditLead extends BaseClass {

	static String leadIDText;

	@Given("Enter first name here {string}")
	public void enterFirstNamne(String fName) {
		driver.findElement(By.xpath("//div[@class='x-form-item x-tab-item']//input[@name='firstName']"))
				.sendKeys(fName);
	}

	@Given("Click on find leads button")
	public void firstNameFind() {
		driver.findElement(By.xpath("//button[contains(text(), 'Find Leads')]")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Given("Click on the first find leads ID")
	public void clickFirstName() {
		WebElement leadID = driver
				.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a"));
		String leadIDText = leadID.getText();
		leadID.click();
		EditLead.leadIDText = leadIDText;
	}

	@Then("Resulting company name should be {string}")
	public void varifyComName(String companyName) {
		String actualComName = driver.findElement(By.id("viewLead_companyName_sp")).getText();
//		sAssert.assertEquals(actualComName, companyName);
		sAssert.assertTrue(actualComName.contains(companyName));
	}

	@Then("Editing company name should be {string}")
	public void editingCompanyName(String cName) {
		driver.findElement(By.id("updateLeadForm_companyName")).clear();
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys(cName);
	}

	@Then("Click on Update Lead")
	public void clickOnUpdateLead() {
		driver.findElement(By.xpath("//input[@value='Update']")).click();
	}

	@Then("Last company name shoud be {string}")
	public void varifyCompanyNameChanged(String lCoName) {
		String changedCompanyName = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		sAssert.assertNotEquals(changedCompanyName, lCoName);
	}
}
